'use strict';

module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.addConstraint('ligneprecommandes', {
      fields: ['ProduitIdProduit'],
      type: 'foreign key',
      name: 'fk_ligneprecommandes_ProduitIdProduit_produits_idProduit',
      references: {
        table: 'produits',
        field: 'idProduit'
      },
      onUpdate: 'CASCADE',
      onDelete: 'SET NULL'
    });
  },

  async down(queryInterface) {
    await queryInterface.removeConstraint('ligneprecommandes', 'fk_ligneprecommandes_ProduitIdProduit_produits_idProduit');
  }
};
