'use strict';

module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.createTable('etapeproductions', {
      idEtapeProduction: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: true,
      },
      descriptionEtapeProduction: {
        type: Sequelize.TEXT,
        allowNull: true,
      },
      dateEtapeProduction: {
        type: Sequelize.DATE,
        allowNull: true,
      },
      idProduit: {
        type: Sequelize.INTEGER,
        allowNull: false,
      },
      idFournisseur: {
        type: Sequelize.INTEGER,
        allowNull: true,
      },
      idProducteur: {
        type: Sequelize.INTEGER,
        allowNull: true,
      },
      createdAt: {
        type: Sequelize.DATE,
        allowNull: false,
      },
      updatedAt: {
        type: Sequelize.DATE,
        allowNull: false,
      },
      createdAt: {
        type: Sequelize.DATE,
        defaultValue: Sequelize.fn('now'),
        allowNull: false
      },
      updatedAt: {
        type: Sequelize.DATE,
        defaultValue: Sequelize.fn('now'),
        allowNull: false
      }
    });
  },

  async down(queryInterface) {
    await queryInterface.dropTable('etapeproductions');
  }
};
