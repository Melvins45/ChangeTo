'use strict';

module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.addConstraint('produitcaracteristiques', {
      fields: ['CaracteristiqueIdCaracteristique'],
      type: 'foreign key',
      name: 'fk_produitcaracteristiques_CaracteristiqueIdCaracteristique_caracteristiques_idCaracteristique',
      references: {
        table: 'caracteristiques',
        field: 'idCaracteristique'
      },
      onUpdate: 'CASCADE',
      onDelete: 'SET NULL'
    });
  },

  async down(queryInterface) {
    await queryInterface.removeConstraint('produitcaracteristiques', 'fk_produitcaracteristiques_CaracteristiqueIdCaracteristique_caracteristiques_idCaracteristique');
  }
};
