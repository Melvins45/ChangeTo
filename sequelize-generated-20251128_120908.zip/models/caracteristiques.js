'use strict';
const {
  Model
} = require('sequelize');

module.exports = (sequelize, DataTypes) => {
  class Caracteristiques extends Model {
    static associate(models) {
    }
  }
  Caracteristiques.init({
    idCaracteristique: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    nomCaracteristique: {
      type: DataTypes.STRING(255),
      allowNull: true
    },
    createdAt: {
      type: DataTypes.DATE,
      allowNull: false
    },
    updatedAt: {
      type: DataTypes.DATE,
      allowNull: false
    },
  }, {
    sequelize,
    modelName: 'Caracteristiques',
    tableName: 'caracteristiques',
    timestamps: true
  });
  return Caracteristiques;
};
