'use strict';
const {
  Model
} = require('sequelize');

module.exports = (sequelize, DataTypes) => {
  class Ligneprecommandes extends Model {
    static associate(models) {
      this.belongsTo(models.Precommandes, { foreignKey: 'PrecommandeIdPrecommande' });
      // In models/precommandes.js consider: this.hasMany(models.Ligneprecommandes, { foreignKey: 'PrecommandeIdPrecommande' });
      this.belongsTo(models.Produits, { foreignKey: 'ProduitIdProduit' });
      // In models/produits.js consider: this.hasMany(models.Ligneprecommandes, { foreignKey: 'ProduitIdProduit' });
    }
  }
  Ligneprecommandes.init({
    quantite: {
      type: DataTypes.INTEGER,
      primaryKey: true,
    },
    createdAt: {
      type: DataTypes.DATE,
      allowNull: false
    },
    updatedAt: {
      type: DataTypes.DATE,
      allowNull: false
    },
    PrecommandeIdPrecommande: {
      type: DataTypes.INTEGER,
      allowNull: false
    },
    ProduitIdProduit: {
      type: DataTypes.INTEGER,
      allowNull: false
    },
  }, {
    sequelize,
    modelName: 'Ligneprecommandes',
    tableName: 'ligneprecommandes',
    timestamps: true
  });
  return Ligneprecommandes;
};
