'use strict';
const {
  Model
} = require('sequelize');

module.exports = (sequelize, DataTypes) => {
  class Produitcaracteristiques extends Model {
    static associate(models) {
      this.belongsTo(models.Produits, { foreignKey: 'ProduitIdProduit' });
      // In models/produits.js consider: this.hasMany(models.Produitcaracteristiques, { foreignKey: 'ProduitIdProduit' });
      this.belongsTo(models.Caracteristiques, { foreignKey: 'CaracteristiqueIdCaracteristique' });
      // In models/caracteristiques.js consider: this.hasMany(models.Produitcaracteristiques, { foreignKey: 'CaracteristiqueIdCaracteristique' });
    }
  }
  Produitcaracteristiques.init({
    valeurCaracteristique: {
      type: DataTypes.STRING(255),
      primaryKey: true,
    },
    createdAt: {
      type: DataTypes.DATE,
      allowNull: false
    },
    updatedAt: {
      type: DataTypes.DATE,
      allowNull: false
    },
    ProduitIdProduit: {
      type: DataTypes.INTEGER,
      allowNull: false
    },
    CaracteristiqueIdCaracteristique: {
      type: DataTypes.INTEGER,
      allowNull: false
    },
  }, {
    sequelize,
    modelName: 'Produitcaracteristiques',
    tableName: 'produitcaracteristiques',
    timestamps: true
  });
  return Produitcaracteristiques;
};
