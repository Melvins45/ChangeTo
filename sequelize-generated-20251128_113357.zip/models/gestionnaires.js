'use strict';
const {
  Model
} = require('sequelize');

module.exports = (sequelize, DataTypes) => {
  class Gestionnaires extends Model {
    static associate(models) {
      this.belongsTo(models.Personnes, { foreignKey: 'idGestionnaire' });
      // In models/personnes.js consider: this.hasMany(models.Gestionnaires, { foreignKey: 'idGestionnaire' });
    }
  }
  Gestionnaires.init({
    idGestionnaire: {
      type: DataTypes.INTEGER,
      primaryKey: true,
    },
    roleGestionnaire: {
      type: DataTypes.STRING(255),
      allowNull: true
    },
    createdAt: {
      type: DataTypes.DATE,
      allowNull: false
    },
    updatedAt: {
      type: DataTypes.DATE,
      allowNull: false
    },
  }, {
    sequelize,
    modelName: 'Gestionnaires',
    tableName: 'gestionnaires',
    timestamps: true
  });
  return Gestionnaires;
};
