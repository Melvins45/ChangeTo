'use strict';

module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.addConstraint('gestionnaires', {
      fields: ['idGestionnaire'],
      type: 'foreign key',
      name: 'fk_gestionnaires_idGestionnaire_personnes_idPersonne',
      references: {
        table: 'personnes',
        field: 'idPersonne'
      },
      onUpdate: 'CASCADE',
      onDelete: 'SET NULL'
    });
  },

  async down(queryInterface) {
    await queryInterface.removeConstraint('gestionnaires', 'fk_gestionnaires_idGestionnaire_personnes_idPersonne');
  }
};
