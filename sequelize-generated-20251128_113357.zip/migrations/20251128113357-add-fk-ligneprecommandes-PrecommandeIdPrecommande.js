'use strict';

module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.addConstraint('ligneprecommandes', {
      fields: ['PrecommandeIdPrecommande'],
      type: 'foreign key',
      name: 'fk_ligneprecommandes_PrecommandeIdPrecommande_precommandes_idPrecommande',
      references: {
        table: 'precommandes',
        field: 'idPrecommande'
      },
      onUpdate: 'CASCADE',
      onDelete: 'SET NULL'
    });
  },

  async down(queryInterface) {
    await queryInterface.removeConstraint('ligneprecommandes', 'fk_ligneprecommandes_PrecommandeIdPrecommande_precommandes_idPrecommande');
  }
};
